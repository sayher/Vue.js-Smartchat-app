import Vue from 'vue'
import { firebaseAuth, firebaseDb } from 'boot/firebase'

let messageRef

const state = {
  userDetail: {},
  users: {},
  message: {}

}
const mutations = {
  setUserDetails (state, payload) {
    state.userDetail = payload
  },
  addUsers (state, payload) {
    // console.log(payload)
    Vue.set(state.users, payload.userId, payload.userDetail)
  },
  updateUsers (state, payload) {
    Object.assign(state.users[payload.userId], payload.userDetail)
  },
  //= === message

  addMessage (state, payload) {
    Vue.set(state.message, payload.messageId, payload.messageDetails)
  },
  clearMessage (state) {
    state.message = {}
  }
}
const actions = {
  registerUser ({ commit }, payload) {
    firebaseAuth.createUserWithEmailAndPassword(payload.email, payload.password)
      .then(response => {
      //  console.log(response)
        let userId = firebaseAuth.currentUser.uid
        firebaseDb.ref('users/' + userId).set({
          name: payload.name,
          email: payload.email,
          online: true
        })
      }).catch(err => {
        console.log(err.message)
      })
  },
  loginUser ({ commit, dispatch }, payload) {
    firebaseAuth.signInWithEmailAndPassword(payload.email, payload.password)
      .then(response => {
        // console.log(response)
        let userId = firebaseAuth.currentUser.uid
        dispatch('firebaseUpdateUser', {
          userId: userId,
          updates: {
            online: true
          }
        })
        this.$router.push('/')
      }).catch(err => {
        console.log(err.message)
      })
  },
  logOut ({ dispatch, state }) {
    firebaseAuth.signOut()
    dispatch('firebaseUpdateUser', {
      userId: state.userDetail.userId,
      updates: {
        online: false
      }
    })
    this.$router.push('/auth')
  },
  handleAuthStateChanged ({ commit, dispatch, state }) {
    firebaseAuth.onAuthStateChanged(function (user) {
      let userId = firebaseAuth.currentUser.uid
      if (user) {
        // User is signed in.
        firebaseDb.ref('users/' + userId).once('value', snapshot => {
          let user = snapshot.val()
          commit('setUserDetails', {
            name: user.name,
            email: user.email,
            userId: userId
          })
          dispatch('firebaseGetUser')
        })
        this.$router.push('/')
      } else {
        // user is logged out

        commit('setUserDetails', {})
        this.$router.replace('/auth')
      }
    })
  },
  firebaseUpdateUser ({}, payload) {
    firebaseDb.ref('users/' + payload.userId).update(payload.updates)
  },
  firebaseGetUser ({ commit }) {
    firebaseDb.ref('users').on('child_added', snapshot => {
      let userDetail = snapshot.val()
      let userId = snapshot.key
      commit('addUsers', {
        userId,
        userDetail
      })
    })
    firebaseDb.ref('users').on('child_changed', snapshot => {
      let userDetail = snapshot.val()
      let userId = snapshot.key
      commit('updateUsers', {
        userId,
        userDetail
      })
    })
  },

  //= =================
  firebaseGetMessages ({ commit, state }, outherUserId) {
    let userId = state.userDetail.userId
    messageRef = firebaseDb.ref('chats/' + userId + '/' + outherUserId)
    messageRef.on('child_added', snapshot => {
      let messageDetails = snapshot.val()
      let messageId = snapshot.key
      commit('addMessage', {
        messageId,
        messageDetails
      })
    })
  },
  firebaseStopGetMessage ({ commit }) {
    if (messageRef) {
      messageRef.off('child_added')
      commit('clearMessage')
    }
  },

  //= ==== send message

  firebaseSentMessage ({ state }, payload) {
    firebaseDb.ref('chats/' + state.userDetail.userId + '/' + payload.otherUserId)
      .push(payload.message)
    payload.message.from = 'them'
    firebaseDb.ref('chats/' + payload.otherUserId + '/' + state.userDetail.userId)
      .push(payload.message)
  }
}

const getters = {

  users: state => {
    let usersFilltered = {}
    Object.keys(state.users).forEach(key => {
      if (key !== state.userDetail.userId) {
        usersFilltered[key] = state.users[key]
      }
    })
    return usersFilltered
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions,
  getters
}
