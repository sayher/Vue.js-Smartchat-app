<template>

  <q-page
    ref="pageChat"
   class=" page-chat flex column ">
    <q-banner v-if="!otherUserDetails.online" class="bg-grey-4 text-center fixed-top">
    {{otherUserDetails.name}} is offline
    </q-banner>
    <div class="q-pa-md column col justify-end">
      <q-chat-message
        v-for="(msg,i) in message"
        :key="i"
        :name="msg.from=='me' ? userDetail.name: otherUserDetails.name"
        :text="[msg.text]"
        :sent="msg.from=='me' ? true:false"
        :bg-color="msg.from=='me' ? 'white': 'light-green-2'"
      />
    </div>
    <q-footer elevated>
      <q-toolbar>
        <q-form  class="full-width">
          <q-input v-model="newMessage" bg-color="white" ref="newMessage" outlined rounded label="Message" dense>
            <template v-slot:after>
              <q-btn round dense flat color="white" icon="send" @click="sentMessage"/>
            </template>
          </q-input>
        </q-form>
      </q-toolbar>
    </q-footer>
  </q-page>
</template>

<script>
import { mapActions, mapState } from 'vuex'
import mixinOtherUserDetails from '../mixins/mixin-other-user-detail.js'
export default {
  mixins: [mixinOtherUserDetails],
  name: 'PageChat',
  data () {
    return {
      newMessage: ''
    }
  },
  computed: {
    ...mapState('store', ['message', 'userDetail'])

  },
  methods: {
    ...mapActions('store', ['firebaseGetMessages', 'firebaseStopGetMessage', 'firebaseSentMessage']),
    sentMessage () {
      this.firebaseSentMessage({
        message: {
          text: this.newMessage,
          from: 'me'
        },
        otherUserId: this.$route.params.otherUserId

      })
      this.newMessage = ''
      this.$refs.newMessage.focus()
    },
    scrollTobutton () {
      let page = this.$refs.pageChat.$el
      setTimeout(() => {
        window.scrollTo(0, page.scrollHeight)
      }, 20)
    }

  },
  watch: {
    message: function (val) {
      if (Object.keys(val).length) {
        this.scrollTobutton()
      }
    }
  },
  mounted () {
    let params = this.$route.params.otherUserId
    this.firebaseGetMessages(params)
  },
  destroyed () {
    this.firebaseStopGetMessage()
  }
}
</script>

<style lang="stylus">
  .page-chat
    background #e2dfd5
    &:after
        content ''
        display block
        position fixed
        left 0
        right 0
        top 0
        bottom 0
        z-index 0
        opacity 0.1
        background-image radial-gradient(closest-side, transparent 0%, transparent 75%, #B6CC66 76%, #B6CC66 85%, #EDFFDB 86%, #EDFFDB 94%, #FFFFFF 95%, #FFFFFF 103%, #D9E6A7 104%, #D9E6A7 112%, #798B3C 113%, #798B3C 121%, #FFFFFF 122%, #FFFFFF 130%, #E0EAD7 131%, #E0EAD7 140%)
        radial-gradient(closest-side, transparent 0%, transparent 75%, #B6CC66 76%, #B6CC66 85%, #EDFFDB 86%, #EDFFDB 94%, #FFFFFF 95%, #FFFFFF 103%, #D9E6A7 104%, #D9E6A7 112%, #798B3C 113%, #798B3C 121%, #FFFFFF 122%, #FFFFFF 130%, #E0EAD7 131%, #E0EAD7 140%)
        background-size 110px 110px
        background-color #C8D3A7
        background-position 0 0, 55px 55px

  .q-message
    z-index 1
  .q-banner
    top 50px
    z-index 2
    opacity 0.8
</style>
