// Firebase App (the core Firebase SDK) is always required and must be listed first
import * as firebase from 'firebase/app'

// If you enabled Analytics in your project, add the Firebase SDK for Analytics
import 'firebase/analytics'

// Add the Firebase products that you want to use
import 'firebase/auth'
import 'firebase/database'

// Your web app's Firebase configuration
var firebaseConfig = {
  apiKey: 'AIzaSyCw9hOCBpSC9-fPF9cTO0TcL4ezWEOOm6g',
  authDomain: 'smartchat-d36d7.firebaseapp.com',
  databaseURL: 'https://smartchat-d36d7.firebaseio.com',
  projectId: 'smartchat-d36d7',
  storageBucket: 'smartchat-d36d7.appspot.com',
  messagingSenderId: '22182365809',
  appId: '1:22182365809:web:36ae9fb1a3ef034fb429d0',
  measurementId: 'G-RT2TY7VM67'
}
// Initialize Firebase
let firebaseApp = firebase.initializeApp(firebaseConfig)
let firebaseAuth = firebaseApp.auth()
let firebaseDb = firebaseApp.database()

export { firebaseAuth, firebaseDb }
