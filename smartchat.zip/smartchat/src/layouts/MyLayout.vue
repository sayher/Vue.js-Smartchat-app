<template>
  <q-layout view="lHh Lpr lFf">
    <q-header elevated>
      <q-toolbar>
        <q-btn
        v-if="$route.fullPath.includes('/chat')"
         v-go-back.single
        icon="arrow_back"
        flat
        danse
        label="Back"
         />
        <q-toolbar-title class="absolute-center">{{title}}</q-toolbar-title>
          <q-btn
          v-if="!userDetail.userId"
          to='/auth'
          class="absolute-right q-pr-sm"
          icon="account_circle"
          no-caps
          flat
          danse
          label="Login"
         />
          <q-btn
          v-else
          @click="logOut"
          class="absolute-right q-pr-sm"
          icon="account_circle"
          no-caps
          flat
          danse
          label="Logout"
         />
      </q-toolbar>
    </q-header>
    <q-page-container>
      <router-view />
    </q-page-container>
  </q-layout>
</template>

<script>
import { mapState, mapActions } from 'vuex'
import mixinOtherUserDetails from '../mixins/mixin-other-user-detail.js'
export default {
  mixins: [mixinOtherUserDetails],
  computed: {
    ...mapState('store', ['userDetail']),

    title () {
      // console.log(this.$route)
      let currentPath = this.$route.fullPath
      let title = ''
      if (currentPath == '/') title = 'SmartChat'
      else if (currentPath.includes('/chat')) title = this.otherUserDetails.name
      else if (currentPath == '/auth') title = 'Login'
      return title
    }
  },
  methods: {
    ...mapActions('store', ['logOut'])
  }
}
</script>
